import './floating-nav.css'

const FloatingNav = () => {
  return (
    <section id='Floating__nav'></section>
  )
}

export default FloatingNav