import './about.css'

const About = () => {
  return (
      <section id='about'><h2>About</h2></section>
    )
}

export default About