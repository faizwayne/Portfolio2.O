import './contact.css'

const Contact = () => {
  return (
    <section id='contact'><h2>Contact</h2></section>
  )
}

export default Contact