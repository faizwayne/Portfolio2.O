import './testimonials.css'

const Testimonials = () => {
  return (
    <section id='testimonials'><h2>Testimonials</h2></section>
  )
}

export default Testimonials