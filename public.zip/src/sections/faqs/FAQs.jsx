import './faqs.css'

const FAQs = () => {
  return (
    <section id='faqs'><h2>FAQs</h2></section>
  )
}

export default FAQs