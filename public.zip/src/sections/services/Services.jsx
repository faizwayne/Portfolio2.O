import './services.css'

const Services = () => {
  return (
    <section id='services'><h2>Services</h2></section>
  )
}

export default Services